import React from 'react';
import './ExpenseList.css';

function ExpenseList() {
  return (
    <div className="ExpenseList">
      <h2>Expense List</h2>
      {/* List of expenses go here */}
    </div>
  );
}

export default ExpenseList;
