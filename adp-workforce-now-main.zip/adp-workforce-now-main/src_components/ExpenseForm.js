import React from 'react';
import './ExpenseForm.css';

function ExpenseForm() {
  return (
    <div className="ExpenseForm">
      <h2>Expense Form</h2>
      {/* Form elements go here */}
    </div>
  );
}

export default ExpenseForm;
