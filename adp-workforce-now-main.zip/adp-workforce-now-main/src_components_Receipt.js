import React from 'react';
import './Receipt.css';

function Receipt() {
 
